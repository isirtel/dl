var group__netif__mib2 =
[
    [ "stats_mib2_netif_ctrs", "structstats__mib2__netif__ctrs.html", [
      [ "ifindiscards", "structstats__mib2__netif__ctrs.html#a4a767e6b835d5ad2f9b73751de2b0947", null ],
      [ "ifinerrors", "structstats__mib2__netif__ctrs.html#afda1a14dc79bb65a33f97f9fb467ec1d", null ],
      [ "ifinnucastpkts", "structstats__mib2__netif__ctrs.html#a111f08290b3c6944108237cefba066dd", null ],
      [ "ifinoctets", "structstats__mib2__netif__ctrs.html#a7e9ddf9b4a17748a9d3f041c1d24ba8e", null ],
      [ "ifinucastpkts", "structstats__mib2__netif__ctrs.html#a9ed42d6329a9616669ba21789fa001d8", null ],
      [ "ifinunknownprotos", "structstats__mib2__netif__ctrs.html#ac34eb01b42f22b1e49ca7c9734e737aa", null ],
      [ "ifoutdiscards", "structstats__mib2__netif__ctrs.html#a3a2aec508fd4466ca8bab10d8dc2c842", null ],
      [ "ifouterrors", "structstats__mib2__netif__ctrs.html#a91b60bb78759c9b655a74bb4fae3346e", null ],
      [ "ifoutnucastpkts", "structstats__mib2__netif__ctrs.html#afd3264670c39cc0d721a35cb6650f8d7", null ],
      [ "ifoutoctets", "structstats__mib2__netif__ctrs.html#a24151d13a55452518e5f7832f48bd5a7", null ],
      [ "ifoutucastpkts", "structstats__mib2__netif__ctrs.html#a24aba9660a2951027b23d4118b57c471", null ]
    ] ],
    [ "MIB2_INIT_NETIF", "group__netif__mib2.html#ga5be1b8cba1d67bf6e7f8851ec91b10f0", null ],
    [ "MIB2_STATS_NETIF_ADD", "group__netif__mib2.html#ga05641438775014b7e13b9e55eba48bed", null ],
    [ "MIB2_STATS_NETIF_INC", "group__netif__mib2.html#ga3c52caf566d37705c6547f2d025afd9f", null ],
    [ "snmp_ifType", "group__netif__mib2.html#ga15378b8dcd2a9dc2985142d864a767ba", null ]
];