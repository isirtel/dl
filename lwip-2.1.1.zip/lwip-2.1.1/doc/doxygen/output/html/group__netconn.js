var group__netconn =
[
    [ "Common functions", "group__netconn__common.html", "group__netconn__common" ],
    [ "TCP only", "group__netconn__tcp.html", "group__netconn__tcp" ],
    [ "UDP only", "group__netconn__udp.html", "group__netconn__udp" ],
    [ "Network buffers", "group__netbuf.html", "group__netbuf" ]
];