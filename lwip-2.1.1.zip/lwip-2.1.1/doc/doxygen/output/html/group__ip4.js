var group__ip4 =
[
    [ "AUTOIP", "group__autoip.html", "group__autoip" ],
    [ "DHCPv4", "group__dhcp4.html", "group__dhcp4" ],
    [ "IGMP", "group__igmp.html", "group__igmp" ],
    [ "ip4_set_default_multicast_netif", "group__ip4.html#ga6ae67c86aa82dccac5df81d93de00420", null ]
];