var altcp__priv_8h =
[
    [ "altcp_alloc", "altcp__priv_8h.html#a6a99f8757c18fbc9b9f30925afbcf4c2", null ],
    [ "altcp_free", "altcp__priv_8h.html#afd7f6b6602e89cff51f8a8ea0315321d", null ]
];